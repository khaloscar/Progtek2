#!/bin/bash
echo "Tests module 1"
python MA1_test_count.py 
python MA1_test_multiply.py 
python MA1_test_largest.py 
python MA1_test_harmonic.py 
python MA1_test_get_binary.py 
python MA1_test_bricklek.py 
python MA1_test_reverse_string.py
