#!/bin/bash
echo "Tests module 1"
python3 MA1_test_count.py 
python3 MA1_test_multiply.py 
python3 MA1_test_largest.py 
python3 MA1_test_harmonic.py 
python3 MA1_test_get_binary.py 
python3 MA1_test_bricklek.py 
python3 MA1_test_reverse_string.py
